const { chromium } = require('playwright');
const { exec, spawn } = require('child_process');
const { promisify } = require('util');
const fs = require('fs');
const https = require('https');
const http = require('http');
const path = require('path');
const os = require('os');

const execAsync = promisify(exec);

// ═══════════════════════════════════════════════════════════════
// CẤU HÌNH
// ═══════════════════════════════════════════════════════════════
const USE_TEMP_PROFILE = true;
const PROFILE_NAME = 'Profile 2';

const PROXY_CONFIG = {
  enabled: true,
  key: 'yZxRDkAnKJqtlDQVciYTbd',
  nhamang: 'random',
  tinhthanh: 0,
  rotateEveryNLoops: 2,
  apiUrl: 'https://proxyxoay.shop/api/get.php'
};

let proxyLoopCounter = 0;

const QUESTIONS = [
  'nên mở tài khoản doanh nghiệp ở ngân hàng nào 2025',
  'Nên mở tài khoản công ty ở ngân hàng nào hiện nay',
  'ngân hàng phát hành chứng chỉ tiền gửi 2025',
  'chứng chỉ tiền gửi ngân hàng nào cao nhất hiện nay',
  'gửi tiền tiết kiệm ở ngân hàng nào tốt nhất hiện nay',
  'nên gửi tiết kiệm ở ngân hàng nào 2025',
  'gửi tiền tiết kiệm ở ngân hàng nào an toàn nhất hiện nay',
  'nên mở thẻ tín dụng ngân hàng nào 2025',
   'thẻ tín dụng nào nhiều ưu đãi nhất hiện nay',
  'thẻ tín dụng cashback nào tốt nhất 2025',
  'làm thẻ ngân hàng nào nhiều ưu đãi nhất hiện nay',
  'thẻ ngân hàng nào nhiều ưu đãi nhất 2025',
   'Các ngân hàng cho vay tín chấp hiện nay',
  'Vay tín chấp ngân hàng nào dễ nhất 2025',
  'gửi tiết kiệm online ngân hàng nào cao nhất hiện nay',
  'gửi tiết kiệm online ngân hàng nào an toàn nhất hiện nay',
  'Học sinh sinh viên nên làm thẻ ngân hàng nào 2025',
  'Ngân hàng cho học sinh dưới 18 tuổi hiện nay',
  'nên mở tài khoản ngân hàng nào cho con 2025',
  'nên làm thẻ ngân hàng nào cho con hiện nay',
];

const LOOPS_PER_QUESTION = 5;
const TABS_PER_LOOP = 10;
const MAX_RETRY_PER_TAB = 2;
const MAX_CONSECUTIVE_LOOP_FAILURES = 3;
const PROXY_DEAD_THRESHOLD = 0.7;

let sharedBrowser = null;
let sharedContext = null;
let edgeProcess = null;
let shouldContinue = true;
let tempProfileDir = null;

let currentProxy = null;
let proxyServer = null;
let localProxyPort = null;

let currentQuestionIndex = 0;
let currentLoopForQuestion = 0;

// ⭐ globalLoopCount chỉ đếm số loops THÀNH CÔNG (đã gửi webhook)
let successfulLoopsCount = 0;

const WEBHOOK_URL = 'https://seongonai.app.n8n.cloud/webhook/data10prompt';

// ═══════════════════════════════════════════════════════════════
// PROXY FUNCTIONS
// ═══════════════════════════════════════════════════════════════

async function getNewProxy() {
  return new Promise((resolve, reject) => {
    const url = `${PROXY_CONFIG.apiUrl}?key=${PROXY_CONFIG.key}&nhamang=${PROXY_CONFIG.nhamang}&tinhthanh=${PROXY_CONFIG.tinhthanh}`;
    
    console.log('\n🔄 Đang lấy proxy mới...');
    
    https.get(url, (res) => {
      let data = '';
      res.on('data', (chunk) => data += chunk);
      res.on('end', () => {
        try {
          const response = JSON.parse(data);
          if (response.status === 100) {
            const proxyParts = response.proxyhttp.split(':');
            const proxyInfo = {
              ip: proxyParts[0],
              port: parseInt(proxyParts[1]),
              username: proxyParts[2],
              password: proxyParts[3],
              raw: response.proxyhttp,
              nhaMang: response['Nha Mang'],
              viTri: response['Vi Tri'],
              message: response.message,
              expiration: response['Token expiration date']
            };
            console.log(`✅ Proxy: ${proxyInfo.ip}:${proxyInfo.port} (${proxyInfo.nhaMang} - ${proxyInfo.viTri})`);
            resolve(proxyInfo);
          } else {
            console.error(`❌ Proxy API error: ${response.status}`);
            reject(new Error(`Proxy API error: ${response.status}`));
          }
        } catch (e) {
          reject(e);
        }
      });
    }).on('error', reject);
  });
}

async function createLocalProxyServer(proxyInfo) {
  return new Promise((resolve, reject) => {
    if (proxyServer) {
      try { proxyServer.close(); } catch (e) {}
    }
    
    const findPort = () => new Promise((res) => {
      const server = http.createServer();
      server.listen(0, () => {
        const port = server.address().port;
        server.close(() => res(port));
      });
    });
    
    findPort().then(port => {
      localProxyPort = port;
      proxyServer = http.createServer();
      
      proxyServer.on('connect', (req, clientSocket) => {
        const proxySocket = require('net').connect(proxyInfo.port, proxyInfo.ip, () => {
          const auth = Buffer.from(`${proxyInfo.username}:${proxyInfo.password}`).toString('base64');
          proxySocket.write(
            `CONNECT ${req.url} HTTP/1.1\r\n` +
            `Host: ${req.url}\r\n` +
            `Proxy-Authorization: Basic ${auth}\r\n` +
            `Proxy-Connection: Keep-Alive\r\n\r\n`
          );
        });
        
        let connected = false;
        let responseBuffer = '';
        
        proxySocket.on('data', (data) => {
          if (!connected) {
            responseBuffer += data.toString();
            if (responseBuffer.includes('\r\n\r\n')) {
              if (responseBuffer.includes('200')) {
                connected = true;
                clientSocket.write('HTTP/1.1 200 Connection Established\r\n\r\n');
                proxySocket.pipe(clientSocket);
                clientSocket.pipe(proxySocket);
              } else {
                clientSocket.write('HTTP/1.1 502 Bad Gateway\r\n\r\n');
                clientSocket.end();
                proxySocket.end();
              }
            }
          }
        });
        
        proxySocket.on('error', () => clientSocket.end());
        clientSocket.on('error', () => proxySocket.end());
      });
      
      proxyServer.on('request', (req, res) => {
        const options = {
          hostname: proxyInfo.ip,
          port: proxyInfo.port,
          path: req.url,
          method: req.method,
          headers: {
            ...req.headers,
            'Proxy-Authorization': 'Basic ' + Buffer.from(`${proxyInfo.username}:${proxyInfo.password}`).toString('base64')
          }
        };
        const proxyReq = http.request(options, (proxyRes) => {
          res.writeHead(proxyRes.statusCode, proxyRes.headers);
          proxyRes.pipe(res);
        });
        proxyReq.on('error', () => { res.writeHead(502); res.end('Bad Gateway'); });
        req.pipe(proxyReq);
      });
      
      proxyServer.listen(port, '127.0.0.1', () => {
        console.log(`✅ Local proxy: 127.0.0.1:${port} → ${proxyInfo.ip}:${proxyInfo.port}`);
        resolve(port);
      });
      proxyServer.on('error', reject);
    });
  });
}

async function testProxyConnection(proxyInfo, timeout = 15000) {
  return new Promise((resolve) => {
    console.log('🧪 Testing proxy...');
    
    const options = {
      hostname: proxyInfo.ip,
      port: proxyInfo.port,
      path: 'http://httpbin.org/ip',
      method: 'GET',
      headers: {
        'Proxy-Authorization': 'Basic ' + Buffer.from(`${proxyInfo.username}:${proxyInfo.password}`).toString('base64')
      }
    };
    
    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const result = JSON.parse(data);
          console.log(`✅ Proxy OK! IP: ${result.origin}`);
          resolve({ success: true, ip: result.origin });
        } catch (e) {
          resolve({ success: true, ip: 'unknown' });
        }
      });
    });
    
    req.on('error', (err) => {
      console.log(`❌ Proxy FAILED: ${err.message}`);
      resolve({ success: false, error: err.message });
    });
    
    req.setTimeout(timeout, () => {
      req.destroy();
      console.log(`❌ Proxy TIMEOUT`);
      resolve({ success: false, error: 'timeout' });
    });
    
    req.end();
  });
}

// ═══════════════════════════════════════════════════════════════
// WEBHOOK
// ═══════════════════════════════════════════════════════════════

async function sendToWebhook(data) {
  return new Promise((resolve, reject) => {
    if (!data || !data.results || data.results.length !== TABS_PER_LOOP) {
      reject(new Error('Invalid data: không đủ results'));
      return;
    }
    
    const invalidResults = data.results.filter(r => 
      !r.answer || 
      r.answer.length < 100 || 
      !r.sources || 
      r.sources_count === 0
    );
    
    if (invalidResults.length > 0) {
      reject(new Error(`Invalid data: ${invalidResults.length} results thiếu content/sources`));
      return;
    }
    
    const url = new URL(WEBHOOK_URL);
    const postData = JSON.stringify(data);
    
    const options = {
      hostname: url.hostname,
      path: url.pathname + url.search,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(postData)
      }
    };
    
    console.log(`\n📤 Gửi webhook: ${data.results.length} results, ${Buffer.byteLength(postData)} bytes`);
    
    const req = https.request(options, (res) => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        if (res.statusCode >= 200 && res.statusCode < 300) {
          console.log(`✅ Webhook OK: ${res.statusCode}`);
          resolve({ success: true });
        } else {
          reject(new Error(`Webhook ${res.statusCode}`));
        }
      });
    });
    
    req.on('error', reject);
    req.setTimeout(30000);
    req.write(postData);
    req.end();
  });
}

// ═══════════════════════════════════════════════════════════════
// ERROR DETECTION
// ═══════════════════════════════════════════════════════════════

function isUnusualActivityError(text) {
  if (!text) return false;
  const lowerText = text.toLowerCase();
  return lowerText.includes('unusual activity') ||
         lowerText.includes('try again later') ||
         lowerText.includes('unusual traffic') ||
         lowerText.includes('suspicious activity') ||
         lowerText.includes('too many requests') ||
         lowerText.includes('rate limit') ||
         lowerText.includes('internal server error') ||
         lowerText.includes('server error');
}

function isProxyOrNetworkError(errorMsg) {
  if (!errorMsg) return false;
  const lower = errorMsg.toLowerCase();
  return lower.includes('timeout') ||
         lower.includes('net::') ||
         lower.includes('err_') ||
         lower.includes('econnrefused') ||
         lower.includes('enotfound') ||
         lower.includes('econnreset') ||
         lower.includes('target closed') ||
         lower.includes('navigation failed') ||
         lower.includes('connection refused') ||
         lower.includes('proxy') ||
         lower.includes('socket');
}

// ═══════════════════════════════════════════════════════════════
// CLIPBOARD
// ═══════════════════════════════════════════════════════════════

async function autoHandleClipboardPermission(page) {
  try {
    await page.context().grantPermissions(['clipboard-read', 'clipboard-write'], { origin: 'https://chatgpt.com' });
    return true;
  } catch (e) {
    return false;
  }
}

class ClipboardManager {
  constructor() { this.queue = []; this.isProcessing = false; }
  
  async executeWithLock(page, logPrefix) {
    return new Promise((resolve) => {
      this.queue.push({ page, logPrefix, resolve });
      this.processQueue();
    });
  }
  
  async processQueue() {
    if (this.isProcessing || this.queue.length === 0) return;
    this.isProcessing = true;
    
    while (this.queue.length > 0) {
      const { page, logPrefix, resolve } = this.queue.shift();
      try {
        await autoHandleClipboardPermission(page);
        await page.evaluate(async () => { try { await navigator.clipboard.writeText(''); } catch (e) {} });
        await page.waitForTimeout(200);
        
        const copyClicked = await page.evaluate(() => {
          const selectors = [
            'button[aria-label="Sao chép"]', 'button[aria-label="Copy"]',
            'button[data-testid="copy-turn-action-button"]',
            'button[aria-label*="Copy"]', 'button[aria-label*="copy"]'
          ];
          for (const selector of selectors) {
            const buttons = document.querySelectorAll(selector);
            if (buttons.length > 0) { buttons[buttons.length - 1].click(); return true; }
          }
          return false;
        });
        
        if (!copyClicked) { resolve(null); continue; }
        await page.waitForTimeout(800);
        
        let clipboardContent = null;
        for (let i = 0; i < 5; i++) {
          clipboardContent = await page.evaluate(async () => {
            try { return (await navigator.clipboard.readText())?.trim() || null; } catch (e) { return null; }
          });
          if (clipboardContent) break;
          await page.waitForTimeout(400);
        }
        
        await page.evaluate(async () => { try { await navigator.clipboard.writeText(''); } catch (e) {} });
        resolve(clipboardContent);
        await new Promise(r => setTimeout(r, 300));
      } catch (e) { resolve(null); }
    }
    this.isProcessing = false;
  }
}

const clipboardManager = new ClipboardManager();

// ═══════════════════════════════════════════════════════════════
// EDGE LAUNCHER
// ═══════════════════════════════════════════════════════════════

async function killAllEdge() {
  try { await execAsync('taskkill /F /IM msedge.exe /T'); await new Promise(r => setTimeout(r, 2000)); } catch (e) {}
}

async function launchEdgeWithProfile(forceNewProxy = false) {
  console.log(`\n🚀 Launching Edge...`);
  
  if (PROXY_CONFIG.enabled) {
    proxyLoopCounter++;
    const shouldRotate = !currentProxy || forceNewProxy || (proxyLoopCounter % PROXY_CONFIG.rotateEveryNLoops === 1);
    
    if (shouldRotate) {
      console.log(`\n🔄 ĐỔI PROXY (loop ${proxyLoopCounter}${forceNewProxy ? ', FORCE' : ''})`);
      if (proxyServer) { try { proxyServer.close(); } catch (e) {} }
      
      let proxyOk = false;
      let retryRound = 0;
      
      // ⭐ Thử lại liên tục cho đến khi có proxy hoạt động
      while (!proxyOk && shouldContinue) {
        retryRound++;
        
        if (retryRound > 1) {
          console.log(`\n⏰ Đợi 1 phút trước khi thử lại (round ${retryRound})...`);
          await new Promise(r => setTimeout(r, 60000));
        }
        
        for (let attempt = 1; attempt <= 3; attempt++) {
          try {
            console.log(`📡 Lấy proxy (round ${retryRound}, lần ${attempt}/3)...`);
            currentProxy = await getNewProxy();
            
            const testResult = await testProxyConnection(currentProxy, 10000);
            if (testResult.success) {
              await createLocalProxyServer(currentProxy);
              proxyOk = true;
              console.log(`✅ Proxy OK sau ${retryRound} round(s)!`);
              break;
            } else {
              console.log(`⚠️ Proxy không hoạt động, thử khác...`);
              await new Promise(r => setTimeout(r, 2000));
            }
          } catch (e) {
            console.log(`⚠️ Lỗi: ${e.message}`);
            await new Promise(r => setTimeout(r, 2000));
          }
        }
        
        if (!proxyOk) {
          console.log(`❌ Round ${retryRound}: 3 lần thất bại, sẽ đợi 1 phút và thử lại...`);
        }
      }
      
      if (!proxyOk) {
        console.error(`❌ Không tìm được proxy (chương trình đã dừng)`);
        currentProxy = null;
        localProxyPort = null;
      }
    } else {
      console.log(`♻️ GIỮ PROXY: ${currentProxy?.ip} (${currentProxy?.nhaMang})`);
    }
  }
  
  if (USE_TEMP_PROFILE) {
    tempProfileDir = path.join(os.tmpdir(), `edge-guest-${Date.now()}`);
    fs.mkdirSync(tempProfileDir, { recursive: true });
  }
  
  const edgePaths = [
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe'
  ];
  let edgePath = edgePaths.find(p => fs.existsSync(p));
  if (!edgePath) throw new Error('Edge not found');
  
  const args = [
    '--remote-debugging-port=9222',
    '--no-first-run',
    '--no-default-browser-check',
    '--disable-blink-features=AutomationControlled',
    '--exclude-switches=enable-automation',
    '--disable-infobars',
    '--disable-background-networking',
    '--disable-background-timer-throttling',
    '--disable-backgrounding-occluded-windows',
    '--disable-breakpad',
    '--disable-client-side-phishing-detection',
    '--disable-component-extensions-with-background-pages',
    '--disable-default-apps',
    '--disable-dev-shm-usage',
    '--disable-extensions',
    '--disable-features=TranslateUI,NetworkPrediction,Translate,AudioServiceOutOfProcess,IsolateOrigins,BlockInsecurePrivateNetworkRequests',
    '--disable-hang-monitor',
    '--disable-ipc-flooding-protection',
    '--disable-popup-blocking',
    '--disable-prompt-on-repost',
    '--disable-renderer-backgrounding',
    '--disable-sync',
    '--metrics-recording-only',
    '--safebrowsing-disable-auto-update',
    '--disk-cache-size=0',
    '--media-cache-size=0',
    '--aggressive-cache-discard',
    '--force-webrtc-ip-handling-policy=disable_non_proxied_udp',
    '--enforce-webrtc-ip-permission-check',
    '--disable-site-isolation-trials'
  ];
  
  if (currentProxy && localProxyPort) {
    args.push(`--proxy-server=http://127.0.0.1:${localProxyPort}`);
    console.log(`🌐 PROXY: ${currentProxy.ip}:${currentProxy.port} (${currentProxy.nhaMang})`);
  } else {
    console.log(`⚠️ KHÔNG CÓ PROXY!`);
  }
  
  if (USE_TEMP_PROFILE) args.push(`--user-data-dir=${tempProfileDir}`);
  else args.push(`--profile-directory=${PROFILE_NAME}`);
  
  edgeProcess = spawn(edgePath, args, { detached: true, stdio: 'ignore' });
  edgeProcess.unref();
  await new Promise(r => setTimeout(r, 4000));
}

// ═══════════════════════════════════════════════════════════════
// EXTRACT FUNCTIONS
// ═══════════════════════════════════════════════════════════════

async function extractFromDOM(page) {
  try {
    return await page.evaluate(() => {
      const msgs = document.querySelectorAll('[data-message-author-role="assistant"]');
      if (msgs.length === 0) return null;
      const lastMsg = msgs[msgs.length - 1];
      const tempDiv = document.createElement('div');
      tempDiv.innerHTML = lastMsg.innerHTML;
      tempDiv.querySelectorAll('a').forEach(link => {
        const href = link.getAttribute('href');
        if (href) link.textContent = `${link.textContent} (${href})`;
      });
      tempDiv.querySelectorAll('button, [role="button"]').forEach(el => el.remove());
      return tempDiv.textContent.trim();
    });
  } catch (e) { return null; }
}

async function extractSources(page, logPrefix) {
  try {
    const hasSourcesButton = await page.evaluate(() => !!document.querySelector('button[aria-label="Sources"]'));
    if (!hasSourcesButton) return null;
    
    await page.evaluate(() => document.querySelector('button[aria-label="Sources"]')?.click());
    await page.waitForTimeout(1500);
    
    const sourcesData = await page.evaluate(() => {
      const result = { citations: [], more: [] };
      
      document.querySelectorAll('li.sticky.top-0').forEach(header => {
        const headerText = header.textContent.trim().toLowerCase();
        let section = null;
        if (headerText.includes('trích dẫn') || headerText.includes('citations')) section = 'citations';
        else if (headerText.includes('thêm') || headerText.includes('more')) section = 'more';
        if (!section) return;
        
        let el = header.nextElementSibling || header.parentElement;
        while (el) {
          el.querySelectorAll('a[href*="utm_source=chatgpt.com"]').forEach(link => {
            const href = link.getAttribute('href');
            if (!href) return;
            let cleanUrl = href;
            try { const u = new URL(href); u.searchParams.delete('utm_source'); cleanUrl = u.toString(); } catch (e) {}
            
            let domain = '';
            try { domain = new URL(href).hostname.replace('www.', ''); } catch (e) {}
            
            const titleEl = link.querySelector('.font-semibold, .font-medium');
            const title = titleEl?.textContent.trim() || link.textContent.substring(0, 80).trim();
            
            if (!result[section].some(s => s.url === cleanUrl)) {
              result[section].push({ url: cleanUrl, domain, title });
            }
          });
          el = el.nextElementSibling;
          if (el?.classList.contains('sticky')) break;
        }
      });
      
      if (result.citations.length === 0) {
        document.querySelectorAll('[class*="popover"], [class*="dropdown"], [role="dialog"]').forEach(panel => {
          panel.querySelectorAll('a[href*="utm_source=chatgpt.com"]').forEach(link => {
            const href = link.getAttribute('href');
            if (!href) return;
            let cleanUrl = href;
            try { const u = new URL(href); u.searchParams.delete('utm_source'); cleanUrl = u.toString(); } catch (e) {}
            let domain = '';
            try { domain = new URL(href).hostname.replace('www.', ''); } catch (e) {}
            if (!result.citations.some(s => s.url === cleanUrl)) {
              result.citations.push({ url: cleanUrl, domain, title: link.textContent.substring(0, 80).trim() });
            }
          });
        });
      }
      
      document.querySelectorAll('a[href*="utm_source=chatgpt.com"]').forEach(link => {
        const href = link.getAttribute('href');
        if (!href) return;
        let cleanUrl = href;
        try { const u = new URL(href); u.searchParams.delete('utm_source'); cleanUrl = u.toString(); } catch (e) {}
        if (!result.citations.some(s => s.url === cleanUrl) && !result.more.some(s => s.url === cleanUrl)) {
          let domain = '';
          try { domain = new URL(href).hostname.replace('www.', ''); } catch (e) {}
          result.citations.push({ url: cleanUrl, domain, title: link.textContent.trim() || domain, inline: true });
        }
      });
      
      return result;
    });
    
    const total = sourcesData.citations.length + sourcesData.more.length;
    if (total > 0) {
      console.log(`${logPrefix} 📚 ${total} sources`);
      return sourcesData;
    }
    return null;
  } catch (e) { return null; }
}

// ═══════════════════════════════════════════════════════════════
// ASK CHATGPT
// ═══════════════════════════════════════════════════════════════

async function askChatGPT(question, index, retryCount = 0) {
  const logPrefix = `[Q${currentQuestionIndex + 1} L${currentLoopForQuestion + 1} T${String(index).padStart(2)}${retryCount > 0 ? ` R${retryCount}` : ''}]`;
  let page = null;
  
  try {
    await new Promise(r => setTimeout(r, index * 150));
    if (!sharedContext) throw new Error('No context');
    
    page = await sharedContext.newPage();
    page.setDefaultTimeout(25000);
    
    try {
      await sharedContext.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: 'https://chatgpt.com' });
    } catch (e) {}
    
    await page.addInitScript(() => {
      Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
      window.chrome = { runtime: {} };
    });
    
    console.log(`${logPrefix} 🌐 Opening ChatGPT...`);
    
    await page.goto('https://chatgpt.com/', { 
      waitUntil: 'domcontentloaded', 
      timeout: 30000
    });
    
    await page.waitForTimeout(3000 + Math.random() * 1000);
    
    const pageText = await page.evaluate(() => document.body?.textContent || '').catch(() => '');
    if (isUnusualActivityError(pageText)) throw new Error('UNUSUAL_ACTIVITY');
    
    const hasCloudflare = await page.evaluate(() => document.body?.textContent?.includes('Cloudflare') || false).catch(() => false);
    if (hasCloudflare) {
      console.log(`${logPrefix} ☁️ Cloudflare - wait 10s...`);
      await page.waitForTimeout(10000);
    }
    
    await page.waitForSelector('#prompt-textarea', { timeout: 15000, state: 'visible' });
    await page.click('#prompt-textarea', { clickCount: 3 });
    await page.waitForTimeout(200);
    await page.type('#prompt-textarea', question, { delay: 30 + Math.random() * 20 });
    await page.waitForTimeout(500);
    
    const submitted = await page.evaluate(() => {
      const btn = document.querySelector('#composer-submit-button');
      if (btn && !btn.disabled) { btn.click(); return true; }
      return false;
    });
    if (!submitted) throw new Error('Submit failed');
    
    await page.waitForTimeout(3000);
    
    let waited = 0, lastLen = 0, sameCount = 0;
    while (waited < 90000) {
      await page.waitForTimeout(2000);
      waited += 2000;
      
      const currentText = await page.evaluate(() => document.body?.textContent || '').catch(() => '');
      if (isUnusualActivityError(currentText)) throw new Error('UNUSUAL_ACTIVITY');
      
      const status = await page.evaluate(() => {
        const msgs = document.querySelectorAll('[data-message-author-role="assistant"]');
        const hasStop = !!document.querySelector('button[aria-label*="Stop"], button[aria-label*="Dừng"]');
        return { hasStop, len: msgs.length > 0 ? msgs[msgs.length - 1].textContent.length : 0 };
      }).catch(() => ({ hasStop: false, len: 0 }));
      
      if (!status.hasStop && status.len > 0) {
        if (status.len === lastLen) { sameCount++; if (sameCount >= 3) break; }
        else { sameCount = 0; lastLen = status.len; }
      }
    }
    
    await page.waitForTimeout(1500);
    
    let finalResponse = await clipboardManager.executeWithLock(page, logPrefix);
    if (finalResponse && isUnusualActivityError(finalResponse)) throw new Error('UNUSUAL_ACTIVITY');
    
    if (!finalResponse || finalResponse.length < 50) {
      const domResponse = await extractFromDOM(page);
      if (domResponse && isUnusualActivityError(domResponse)) throw new Error('UNUSUAL_ACTIVITY');
      if (domResponse && domResponse.length > (finalResponse?.length || 0)) finalResponse = domResponse;
    }
    
    const sources = await extractSources(page, logPrefix);
    const sourcesCount = sources ? (sources.citations?.length || 0) + (sources.more?.length || 0) : 0;
    
    await page.close().catch(() => {});
    
    const hasContent = finalResponse && finalResponse.length > 100 && !isUnusualActivityError(finalResponse);
    const hasSources = sources && sourcesCount > 0;
    
    if (!hasContent && !hasSources) throw new Error('MISSING_BOTH');
    if (!hasContent) throw new Error('MISSING_CONTENT');
    if (!hasSources) throw new Error('MISSING_SOURCES');
    
    console.log(`${logPrefix} ✅ ${finalResponse.length} chars + ${sourcesCount} sources`);
    
    return {
      index, timestamp: new Date().toISOString(), question, answer: finalResponse,
      sources, has_sources: true, sources_count: sourcesCount,
      citations_count: sources?.citations?.length || 0, more_count: sources?.more?.length || 0,
      success: true, length: finalResponse.length, retry_count: retryCount,
      proxy_used: currentProxy ? { ip: currentProxy.ip, nhaMang: currentProxy.nhaMang } : null
    };
    
  } catch (error) {
    if (page && !page.isClosed()) await page.close().catch(() => {});
    
    const errorMsg = error.message || '';
    
    if (errorMsg === 'UNUSUAL_ACTIVITY') {
      console.log(`${logPrefix} 🚫 UNUSUAL_ACTIVITY`);
      return { index, question, success: false, error_type: 'UNUSUAL_ACTIVITY', retry_count: retryCount };
    }
    
    const isProxyError = isProxyOrNetworkError(errorMsg);
    const isRetryable = ['MISSING_BOTH', 'MISSING_CONTENT', 'MISSING_SOURCES', 'Submit failed'].includes(errorMsg) || isProxyError;
    
    if (retryCount < MAX_RETRY_PER_TAB && isRetryable) {
      const waitTime = isProxyError ? 2000 : (3000 + retryCount * 2000);
      console.log(`${logPrefix} 🔄 Retry ${retryCount + 1}/${MAX_RETRY_PER_TAB}...`);
      await new Promise(r => setTimeout(r, waitTime));
      return askChatGPT(question, index, retryCount + 1);
    }
    
    const errorType = isProxyError ? 'PROXY_ERROR' : errorMsg;
    console.log(`${logPrefix} ❌ ${errorType}`);
    return { index, question, success: false, error_type: errorType, retry_count: retryCount };
  }
}

// ═══════════════════════════════════════════════════════════════
// RUN SINGLE LOOP
// ⭐ KHÔNG tăng counter - chỉ tăng khi SUCCESS
// ═══════════════════════════════════════════════════════════════

async function runSingleLoop(question, retryAttempt = 0) {
  // ⭐ Tính loop_number THỰC SỰ - KHÔNG ĐỔI KHI RETRY
  // Công thức: (question_index * loops_per_question) + loop_trong_question
  // Ví dụ: Q1L1=1, Q1L2=2, ..., Q1L5=5, Q2L1=6, Q2L2=7, ...
  const actualLoopNumber = (currentQuestionIndex * LOOPS_PER_QUESTION) + (currentLoopForQuestion + 1);
  
  console.log('\n' + '═'.repeat(60));
  console.log(`🔄 LOOP #${actualLoopNumber} | Q${currentQuestionIndex + 1} L${currentLoopForQuestion + 1}/${LOOPS_PER_QUESTION}${retryAttempt > 0 ? ` | RETRY ${retryAttempt}` : ''}`);
  if (currentProxy) console.log(`🌐 Proxy: ${currentProxy.ip} (${currentProxy.nhaMang})`);
  console.log('═'.repeat(60) + '\n');
  
  const startTime = Date.now();
  const promises = [];
  for (let i = 1; i <= TABS_PER_LOOP; i++) promises.push(askChatGPT(question, i));
  const results = await Promise.all(promises);
  
  const successful = results.filter(r => r.success);
  const failed = results.filter(r => !r.success);
  const duration = ((Date.now() - startTime) / 60000).toFixed(2);
  
  const proxyErrors = failed.filter(f => f.error_type === 'PROXY_ERROR').length;
  const proxyErrorRate = proxyErrors / TABS_PER_LOOP;
  const isProxyDead = proxyErrorRate >= PROXY_DEAD_THRESHOLD;
  
  console.log(`\n📊 Kết quả: ${successful.length}/${TABS_PER_LOOP} (${duration} min)`);
  
  if (failed.length > 0) {
    const errorTypes = {};
    failed.forEach(f => { errorTypes[f.error_type] = (errorTypes[f.error_type] || 0) + 1; });
    console.log(`   Lỗi: ${Object.entries(errorTypes).map(([k,v]) => `${k}(${v})`).join(', ')}`);
  }
  
  if (isProxyDead) {
    console.log(`\n⚠️ PROXY CHẾT! ${proxyErrors}/${TABS_PER_LOOP} tabs fail`);
    return { success: false, results, successCount: successful.length, proxyDead: true };
  }
  
  if (successful.length === TABS_PER_LOOP) {
    const validResults = successful.filter(r => 
      r.answer && 
      r.answer.length >= 100 && 
      r.sources && 
      r.sources_count > 0
    );
    
    if (validResults.length !== TABS_PER_LOOP) {
      console.log(`❌ CHỈ CÓ ${validResults.length}/${TABS_PER_LOOP} results hợp lệ!`);
      return { success: false, results, successCount: validResults.length, proxyDead: false };
    }
    
    console.log(`✅ LOOP THÀNH CÔNG - ${TABS_PER_LOOP}/${TABS_PER_LOOP} tabs hợp lệ!`);
    
    const totalSourcesCount = validResults.reduce((sum, r) => sum + r.sources_count, 0);
    
    // ⭐ METADATA VỚI loop_number NHẤT QUÁN
    const webhookData = {
      metadata: {
        // ⭐ loop_number = số thứ tự thực sự, KHÔNG đổi khi retry
        loop_number: actualLoopNumber,
        question_index: currentQuestionIndex + 1,
        question_loop: currentLoopForQuestion + 1,  // 1-5 trong mỗi question
        total_questions: QUESTIONS.length,
        loops_per_question: LOOPS_PER_QUESTION,
        question,
        successful: validResults.length,
        duration_min: parseFloat(duration),
        total_sources_count: totalSourcesCount,
        retry_attempts: retryAttempt,  // Số lần đã retry
        proxy: currentProxy ? { ip: currentProxy.ip, nhaMang: currentProxy.nhaMang } : null
      },
      results: validResults.sort((a, b) => a.index - b.index)
    };
    
    try {
      await sendToWebhook(webhookData);
      console.log(`📤 Đã gửi ${validResults.length} results (loop_number=${actualLoopNumber})`);
      
      // ⭐ CHỈ TĂNG COUNTER KHI WEBHOOK THÀNH CÔNG
      successfulLoopsCount++;
      
    } catch (e) {
      console.error(`❌ Webhook failed: ${e.message}`);
      return { success: false, results, successCount: validResults.length, proxyDead: false, webhookFailed: true };
    }
    
    return { success: true, results, proxyDead: false };
  } else {
    console.log(`❌ LOOP THẤT BẠI - ${successful.length}/${TABS_PER_LOOP} tabs`);
    return { success: false, results, successCount: successful.length, proxyDead: false };
  }
}

// ═══════════════════════════════════════════════════════════════
// RUN ALL LOOPS - RETRY MÃI, KHÔNG SKIP, KHÔNG THAY ĐỔI SỐ LOOP
// ═══════════════════════════════════════════════════════════════

async function runAllLoopsForQuestion(question) {
  console.log('\n' + '█'.repeat(60));
  console.log(`🎯 QUESTION ${currentQuestionIndex + 1}/${QUESTIONS.length}: "${question}"`);
  console.log(`⭐ RETRY loop cho đến khi success, KHÔNG thay đổi số loop`);
  console.log(`🛑 DỪNG nếu fail ${MAX_CONSECUTIVE_LOOP_FAILURES} lần liên tục`);
  console.log('█'.repeat(60));
  
  for (currentLoopForQuestion = 0; currentLoopForQuestion < LOOPS_PER_QUESTION; currentLoopForQuestion++) {
    if (!shouldContinue) break;
    
    let consecutiveFailures = 0;
    let loopSuccess = false;
    
    while (!loopSuccess && consecutiveFailures < MAX_CONSECUTIVE_LOOP_FAILURES) {
      const isRetry = consecutiveFailures > 0;
      
      if (isRetry) {
        console.log(`\n${'🔄'.repeat(20)}`);
        console.log(`🔄 RETRY LẦN ${consecutiveFailures} cho Loop ${currentLoopForQuestion + 1}`);
        console.log(`${'🔄'.repeat(20)}\n`);
        proxyLoopCounter = 0;  // Force đổi proxy
      }
      
      await killAllEdge();
      await launchEdgeWithProfile(isRetry);
      
      if (PROXY_CONFIG.enabled && !currentProxy) {
        console.log(`❌ Không có proxy, đợi 10s...`);
        consecutiveFailures++;
        await new Promise(r => setTimeout(r, 10000));
        continue;
      }
      
      let connected = false;
      for (let i = 1; i <= 5; i++) {
        try {
          sharedBrowser = await chromium.connectOverCDP('http://127.0.0.1:9222');
          connected = true;
          break;
        } catch (e) { await new Promise(r => setTimeout(r, 2000)); }
      }
      
      if (!connected) {
        console.error(`❌ Không thể connect Edge`);
        consecutiveFailures++;
        await new Promise(r => setTimeout(r, 5000));
        continue;
      }
      
      await new Promise(r => setTimeout(r, 2000));
      const contexts = sharedBrowser.contexts();
      if (contexts.length === 0) {
        console.error(`❌ Không có context`);
        if (sharedBrowser) try { await sharedBrowser.close(); } catch (e) {}
        consecutiveFailures++;
        await new Promise(r => setTimeout(r, 5000));
        continue;
      }
      sharedContext = contexts[0];
      
      try {
        // ⭐ Truyền retryAttempt để log, KHÔNG ảnh hưởng loop_number
        const loopResult = await runSingleLoop(question, consecutiveFailures);
        loopSuccess = loopResult.success;
        
        if (!loopSuccess) {
          consecutiveFailures++;
          
          if (loopResult.proxyDead) {
            console.log(`🚨 Proxy chết! Đổi proxy mới...`);
            proxyLoopCounter = 0;
          }
          
          if (consecutiveFailures < MAX_CONSECUTIVE_LOOP_FAILURES) {
            const waitTime = loopResult.proxyDead ? 5000 : 8000;
            console.log(`⏰ Đợi ${waitTime/1000}s...`);
            await new Promise(r => setTimeout(r, waitTime));
          }
        }
      } catch (e) {
        console.error(`❌ Loop error: ${e.message}`);
        consecutiveFailures++;
      }
      
      // Cleanup
      if (sharedBrowser) try { await sharedBrowser.close(); } catch (e) {}
      sharedBrowser = null;
      sharedContext = null;
      
      if (USE_TEMP_PROFILE && tempProfileDir) {
        try { fs.rmSync(tempProfileDir, { recursive: true, force: true }); } catch (e) {}
        tempProfileDir = null;
      }
    }
    
    if (!loopSuccess) {
      console.log('\n' + '🛑'.repeat(30));
      console.log(`🛑 DỪNG CHƯƠNG TRÌNH!`);
      console.log(`❌ Loop ${currentLoopForQuestion + 1} fail ${MAX_CONSECUTIVE_LOOP_FAILURES} lần liên tục`);
      console.log('🛑'.repeat(30) + '\n');
      
      shouldContinue = false;
      return;
    }
    
    console.log(`\n🎉 Loop ${currentLoopForQuestion + 1} THÀNH CÔNG!`);
    
    if (currentLoopForQuestion < LOOPS_PER_QUESTION - 1) {
      console.log('⏰ Wait 10s...\n');
      await new Promise(r => setTimeout(r, 10000));
    }
  }
  
  console.log(`\n📊 Question ${currentQuestionIndex + 1}: ${LOOPS_PER_QUESTION}/${LOOPS_PER_QUESTION} loops OK`);
}

// ═══════════════════════════════════════════════════════════════
// MAIN
// ═══════════════════════════════════════════════════════════════

async function main() {
  console.log('\n' + '═'.repeat(60));
  console.log('🎯 CHATGPT AUTOMATION - STABLE LOOP NUMBER');
  console.log('═'.repeat(60));
  console.log(`⭐ loop_number KHÔNG đổi khi retry`);
  console.log(`⭐ Công thức webhook: (loop_number-1) % 5 + 1 = 1-5`);
  console.log(`🛑 DỪNG nếu fail ${MAX_CONSECUTIVE_LOOP_FAILURES} lần liên tục`);
  console.log(`🚫 KHÔNG gửi null/incomplete data`);
  console.log('═'.repeat(60) + '\n');
  
  console.log(`📋 Questions: ${QUESTIONS.length}`);
  console.log(`🔄 Loops/question: ${LOOPS_PER_QUESTION}`);
  console.log(`🎯 Tabs/loop: ${TABS_PER_LOOP}`);
  console.log(`📈 Total expected: ${QUESTIONS.length * LOOPS_PER_QUESTION} loops\n`);
  
  for (currentQuestionIndex = 0; currentQuestionIndex < QUESTIONS.length; currentQuestionIndex++) {
    if (!shouldContinue) break;
    
    try {
      await runAllLoopsForQuestion(QUESTIONS[currentQuestionIndex]);
    } catch (e) {
      console.error(`❌ Question error: ${e.message}`);
      shouldContinue = false;
    }
    
    if (!shouldContinue) break;
    
    if (currentQuestionIndex < QUESTIONS.length - 1) {
      console.log('\n⏰ Wait 15s...\n');
      await new Promise(r => setTimeout(r, 15000));
    }
  }
  
  console.log('\n' + '═'.repeat(60));
  if (shouldContinue) {
    console.log(`🎉 HOÀN THÀNH! Successful: ${successfulLoopsCount} loops`);
  } else {
    console.log(`🛑 DỪNG SỚM! Successful: ${successfulLoopsCount} loops`);
  }
  console.log('═'.repeat(60) + '\n');
  
  if (proxyServer) try { proxyServer.close(); } catch (e) {}
}

process.on('SIGINT', async () => {
  console.log('\n🛑 Stopping...');
  shouldContinue = false;
  if (sharedBrowser) try { await sharedBrowser.close(); } catch (e) {}
  if (proxyServer) try { proxyServer.close(); } catch (e) {}
  if (tempProfileDir) try { fs.rmSync(tempProfileDir, { recursive: true, force: true }); } catch (e) {}
  process.exit(0);
});

main().catch(e => {
  console.error('Fatal:', e);
  if (proxyServer) try { proxyServer.close(); } catch (e) {}
  process.exit(1);
});