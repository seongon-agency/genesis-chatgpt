const { chromium } = require('playwright');
const fs = require('fs');

const URLS = [
  'https://bizhub.vietnamnews.vn/sacombank-named-best-in-treasury-and-working-capital-in-vn-for-4th-straight-year-post379756.html',
  'https://www.vpbank.com.vn/bi-kip-va-chia-se/corporate-story-and-tips/corporate-sat-category/top-10-thuong-hieu-ngan-hang',
  'https://www.vietcombank.com.vn/vi-VN/Trang-thong-tin-dien-tu/Articles/2025/08/06/20250806_VCB-lan-thu-9-lien-tiep-dan-dau-danh-sach-top-10-ngan-hang-hieu-qua',
  'https://vietnambiz.vn/top-10-ngan-hang-co-lai-thuan-tu-dich-vu-cao-nhat-quy-i2025-techcombank-vuot-nhom-big4-20255691848662.htm',
];

const KEYWORDS = ['Techcombank'];
const CONCURRENCY = 10;
const PAGE_TIMEOUT = 30000;  // 30s timeout

// Các domain có vấn đề HTTP2 - không block resources
const PROBLEMATIC_DOMAINS = ['vietcombank.com.vn', 'vcb.com.vn'];

// Kiểm tra URL có phải PDF/download không
function isPdfOrDownload(url) {
  const lowerUrl = url.toLowerCase();
  return lowerUrl.endsWith('.pdf') || 
         lowerUrl.includes('.pdf?') ||
         lowerUrl.includes('/pdf/') ||
         lowerUrl.includes('/download') ||
         lowerUrl.includes('file-pdf');
}

function logMemory(label = '') {
  const used = process.memoryUsage();
  console.log(`💾 ${label} Memory: RSS=${Math.round(used.rss / 1024 / 1024)}MB, Heap=${Math.round(used.heapUsed / 1024 / 1024)}MB`);
}

function forceGC() {
  if (global.gc) {
    global.gc();
    console.log('🗑️  Garbage collection executed');
  }
}

async function countKeywords(browser, url) {
  // Kiểm tra PDF trước
  if (isPdfOrDownload(url)) {
    console.log(`🌐 ${url}`);
    console.log(`   ⏭️ Bỏ qua - URL là file PDF/Download`);
    
    const skipResults = {};
    for (const kw of KEYWORDS) {
      skipResults[kw] = 'skipped';
    }
    return { 
      url, 
      status: 'skipped',
      reason: 'PDF/Download file',
      total_keywords: 0,
      keyword_counts: skipResults
    };
  }

  let context = null;
  let page = null;
  
  try {
    const isProblematic = PROBLEMATIC_DOMAINS.some(d => url.includes(d));
    
    // Context với headers đầy đủ
    context = await browser.newContext({
      userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      viewport: { width: 1920, height: 1080 },
      locale: 'vi-VN',
      ignoreHTTPSErrors: true,
      bypassCSP: true,
      extraHTTPHeaders: {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7',
        'Accept-Encoding': 'gzip, deflate',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'none',
        'Sec-Fetch-User': '?1',
      },
    });
    
    // Chỉ block resources nếu KHÔNG phải domain có vấn đề
    if (!isProblematic) {
      await context.route('**/*', (route) => {
        const resourceType = route.request().resourceType();
        const reqUrl = route.request().url();
        
        if (['image', 'media', 'font', 'stylesheet'].includes(resourceType)) {
          return route.abort();
        }
        
        const blockedDomains = [
          'google-analytics.com',
          'googletagmanager.com',
          'facebook.net',
          'doubleclick.net',
          'googlesyndication.com',
        ];
        
        if (blockedDomains.some(domain => reqUrl.includes(domain))) {
          return route.abort();
        }
        
        return route.continue();
      });
    }
    
    page = await context.newPage();
    
    page.setDefaultTimeout(PAGE_TIMEOUT);
    page.setDefaultNavigationTimeout(PAGE_TIMEOUT);
    
    // Xử lý download event
    page.on('download', async (download) => {
      console.log(`   📥 Download detected: ${download.suggestedFilename()}`);
      await download.cancel();
    });
    
    await page.addInitScript(() => {
      Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
      window.chrome = { runtime: {} };
      Object.defineProperty(navigator, 'plugins', { get: () => [1, 2, 3, 4, 5] });
      Object.defineProperty(navigator, 'languages', { get: () => ['vi-VN', 'vi', 'en-US', 'en'] });
    });
    
    console.log(`🌐 ${url}`);
    
    // ⭐ CHỈ THỬ 1 LẦN với domcontentloaded
    await page.goto(url, { 
      waitUntil: 'domcontentloaded', 
      timeout: PAGE_TIMEOUT 
    });
    
    await page.waitForTimeout(2000);
    
    const pageText = await page.evaluate(() => {
      document.querySelectorAll('script, style, noscript, iframe, img, video, audio, svg, canvas').forEach(s => s.remove());
      const text = document.body.innerText.toLowerCase();
      document.body.innerHTML = '';
      return text;
    });
    
    const results = {};
    let total = 0;
    
    for (const kw of KEYWORDS) {
      const regex = new RegExp(kw.toLowerCase(), 'gi');
      const count = (pageText.match(regex) || []).length;
      results[kw] = count;
      total += count;
    }
    
    console.log(`   ✅ Tổng: ${total} từ khóa`);
    
    return { 
      url, 
      status: 'success',
      total_keywords: total, 
      keyword_counts: results
    };
    
  } catch (e) {
    const errorMsg = e.message.split('\n')[0];
    
    // Xử lý lỗi download
    if (e.message.includes('Download is starting')) {
      console.log(`   ⏭️ Bỏ qua - URL trigger download`);
      const skipResults = {};
      for (const kw of KEYWORDS) {
        skipResults[kw] = 'skipped';
      }
      return { 
        url, 
        status: 'skipped',
        reason: 'Download triggered',
        total_keywords: 0,
        keyword_counts: skipResults
      };
    }
    
    // ⭐ LỖI -> GHI ERROR VÀ BỎ QUA (không retry)
    console.log(`   ❌ Lỗi: ${errorMsg}`);
    
    const errorResults = {};
    for (const kw of KEYWORDS) {
      errorResults[kw] = 'error';
    }
    
    return { 
      url, 
      status: 'error',
      error_message: errorMsg,
      total_keywords: 'error',
      keyword_counts: errorResults
    };
    
  } finally {
    try {
      if (page) await page.close().catch(() => {});
      if (context) await context.close().catch(() => {});
    } catch (cleanupError) {}
  }
}

function chunkArray(array, size) {
  const chunks = [];
  for (let i = 0; i < array.length; i += size) {
    chunks.push(array.slice(i, i + size));
  }
  return chunks;
}

const BROWSER_ARGS = [
  '--disable-blink-features=AutomationControlled',
  '--disable-features=IsolateOrigins,site-per-process',
  '--disable-site-isolation-trials',
  '--disable-web-security',
  '--no-sandbox',
  '--disable-setuid-sandbox',
  '--disable-dev-shm-usage',
  '--disable-accelerated-2d-canvas',
  '--disable-gpu',
  '--js-flags=--max-old-space-size=512',
  '--disable-extensions',
  '--disable-background-networking',
  '--disable-default-apps',
  '--disable-sync',
  '--disable-translate',
  '--mute-audio',
  '--no-first-run',
  '--safebrowsing-disable-auto-update',
  '--disable-http2',
  '--disable-quic',
];

async function launchBrowser() {
  return await chromium.launch({ 
    headless: true,
    args: BROWSER_ARGS
  });
}

async function main() {
  console.log(`🚀 BẮT ĐẦU (HEADLESS) - Chạy song song ${CONCURRENCY} tab`);
  console.log(`📋 Tổng số URLs: ${URLS.length}`);
  console.log(`🔑 Keywords: ${KEYWORDS.join(', ')}`);
  console.log(`⚡ Mỗi URL chỉ thử 1 lần - lỗi sẽ bỏ qua\n`);
  logMemory('Initial');
  
  const allResults = [];
  const batches = chunkArray(URLS, CONCURRENCY);
  const startTime = Date.now();
  
  for (let i = 0; i < batches.length; i++) {
    console.log(`\n📦 Batch ${i + 1}/${batches.length} (${batches[i].length} URLs)\n`);
    
    console.log('🌐 Launching new browser instance...');
    const browser = await launchBrowser();
    
    const batchResults = await Promise.all(
      batches[i].map(url => countKeywords(browser, url))
    );
    
    allResults.push(...batchResults);
    
    console.log('\n🔥 Closing browser to free memory...');
    await browser.close();
    
    forceGC();
    logMemory(`After batch ${i + 1}`);
    
    if (i < batches.length - 1) {
      console.log('⏳ Chờ 1s trước batch tiếp theo...');
      await new Promise(r => setTimeout(r, 1000));
    }
  }
  
  forceGC();
  logMemory('Final');
  
  fs.writeFileSync('keywords-result.json', JSON.stringify(allResults, null, 2));
  
  const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
  const success = allResults.filter(r => r.status === 'success').length;
  const skipped = allResults.filter(r => r.status === 'skipped').length;
  const errors = allResults.filter(r => r.status === 'error');
  
  console.log('\n' + '='.repeat(60));
  console.log('📊 KẾT QUẢ TỔNG HỢP');
  console.log('='.repeat(60));
  console.log(`✅ Thành công: ${success}/${URLS.length}`);
  console.log(`⏭️ Bỏ qua: ${skipped}/${URLS.length}`);
  console.log(`❌ Thất bại: ${errors.length}/${URLS.length}`);
  console.log(`⏱️  Thời gian: ${elapsed}s`);
  console.log(`📁 File kết quả: keywords-result.json`);
  
  if (errors.length > 0) {
    console.log('\n❌ Các URL bị lỗi:');
    errors.forEach(e => {
      console.log(`   - ${e.url}`);
      console.log(`     Lỗi: ${e.error_message}`);
    });
  }
}

process.on('uncaughtException', (err) => {
  console.error('❌ Uncaught Exception:', err.message);
  process.exit(1);
});

process.on('unhandledRejection', (reason) => {
  console.error('❌ Unhandled Rejection:', reason);
  process.exit(1);
});

main();