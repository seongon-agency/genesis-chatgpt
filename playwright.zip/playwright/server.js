const express = require('express');
const { chromium } = require('playwright');
const WebSocket = require('ws');
const http = require('http');
const axios = require('axios');

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));
app.use(express.static('public'));

const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

let clients = [];

wss.on('connection', (ws) => {
  clients.push(ws);
  console.log('Client connected');
  
  ws.on('close', () => {
    clients = clients.filter(client => client !== ws);
    console.log('Client disconnected');
  });
});

function sendLog(message, type = 'info') {
  const logData = { message, type, timestamp: new Date().toISOString() };
  clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify(logData));
    }
  });
}

const KEYWORDS = ['Techcombank'];
const WEBHOOK_URL = 'https://seongonai.app.n8n.cloud/webhook/url-check';
const PAGE_TIMEOUT = 30000;  // 30s timeout

const BROWSER_ARGS = [
  '--disable-blink-features=AutomationControlled',
  '--disable-features=IsolateOrigins,site-per-process',
  '--disable-site-isolation-trials',
  '--disable-web-security',
  '--no-sandbox',
  '--disable-setuid-sandbox',
  '--disable-dev-shm-usage',
  '--disable-accelerated-2d-canvas',
  '--disable-gpu',
  '--disable-http2',
  '--disable-quic',
  '--disable-extensions',
  '--disable-background-networking',
];

// Kiểm tra PDF/Download
function isPdfOrDownload(url) {
  const lowerUrl = url.toLowerCase();
  return lowerUrl.endsWith('.pdf') || 
         lowerUrl.includes('.pdf?') ||
         lowerUrl.includes('.pdf/') ||
         lowerUrl.includes('/pdf/') ||
         lowerUrl.includes('file-pdf') ||
         lowerUrl.includes('/download/') ||
         lowerUrl.includes('?download=');
}

// Các domain có vấn đề - không block resources
const PROBLEMATIC_DOMAINS = ['vietcombank.com.vn', 'vcb.com.vn'];

async function sendBatchToWebhook(batch, batchNumber) {
  try {
    const payload = {
      batch_number: batchNumber,
      total_urls: batch.length,
      results: batch,
      timestamp: new Date().toISOString()
    };
    
    await axios.post(WEBHOOK_URL, payload, {
      headers: { 'Content-Type': 'application/json' },
      timeout: 10000
    });
    
    sendLog(`📤 Đã gửi batch ${batchNumber} (${batch.length} URLs) qua webhook`, 'success');
  } catch (error) {
    sendLog(`⚠️ Lỗi gửi webhook batch ${batchNumber}: ${error.message}`, 'error');
  }
}

async function countKeywords(browser, url, index, total) {
  sendLog(`🌐 [${index}/${total}] ${url}`, 'url');
  
  // Kiểm tra PDF/Download
  if (isPdfOrDownload(url)) {
    sendLog(`   ⏭️ Bỏ qua - URL là file PDF/Download`, 'warning');
    const skipResults = {};
    for (const kw of KEYWORDS) {
      skipResults[kw] = 'skipped';
    }
    return { 
      url, status: 'skipped', reason: 'PDF/Download file',
      keyword_counts: skipResults, timestamp: new Date().toISOString(),
      index, total
    };
  }

  let context = null;
  let page = null;
  
  try {
    const isProblematic = PROBLEMATIC_DOMAINS.some(d => url.includes(d));
    
    context = await browser.newContext({
      userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      viewport: { width: 1920, height: 1080 },
      locale: 'vi-VN',
      ignoreHTTPSErrors: true,
      bypassCSP: true,
      extraHTTPHeaders: {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7',
        'Accept-Encoding': 'gzip, deflate',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'none',
        'Sec-Fetch-User': '?1',
      },
    });
    
    if (!isProblematic) {
      await context.route('**/*', (route) => {
        const resourceType = route.request().resourceType();
        if (['image', 'media', 'font', 'stylesheet'].includes(resourceType)) {
          return route.abort();
        }
        return route.continue();
      });
    }
    
    page = await context.newPage();
    
    page.setDefaultTimeout(PAGE_TIMEOUT);
    page.setDefaultNavigationTimeout(PAGE_TIMEOUT);
    
    page.on('download', async (download) => {
      sendLog(`   📥 Phát hiện download: ${download.suggestedFilename()}`, 'warning');
      await download.cancel();
    });
    
    await page.addInitScript(() => {
      Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
      window.chrome = { runtime: {} };
      Object.defineProperty(navigator, 'plugins', { get: () => [1, 2, 3, 4, 5] });
    });
    
    // ⭐ CHỈ THỬ 1 LẦN với domcontentloaded
    await page.goto(url, { 
      waitUntil: 'domcontentloaded', 
      timeout: PAGE_TIMEOUT 
    });
    
    await page.waitForTimeout(2000);
    
    const pageText = await page.evaluate(() => {
      document.querySelectorAll('script, style, noscript, iframe').forEach(s => s.remove());
      return document.body.innerText.toLowerCase();
    });
    
    const results = {};
    for (const kw of KEYWORDS) {
      const regex = new RegExp(kw.toLowerCase(), 'gi');
      const count = (pageText.match(regex) || []).length;
      results[kw] = count > 0 ? 1 : 0;
    }
    
    const keywordResults = Object.entries(results)
      .map(([kw, val]) => `${kw}: ${val}`)
      .join(', ');
    sendLog(`   ✅ ${keywordResults}`, 'success');
    
    return { 
      url, status: 'success',
      keyword_counts: results,
      timestamp: new Date().toISOString(),
      index, total
    };
    
  } catch (e) {
    const errorMsg = e.message.split('\n')[0];
    
    // Xử lý lỗi download
    if (e.message.includes('Download is starting')) {
      sendLog(`   ⏭️ URL trigger download - bỏ qua`, 'warning');
      const skipResults = {};
      for (const kw of KEYWORDS) {
        skipResults[kw] = 'skipped';
      }
      return { 
        url, status: 'skipped', reason: 'Download triggered',
        keyword_counts: skipResults, timestamp: new Date().toISOString(),
        index, total
      };
    }
    
    // ⭐ LỖI -> GHI ERROR VÀ BỎ QUA (không retry)
    sendLog(`   ❌ Lỗi: ${errorMsg}`, 'error');
    
    const errorResults = {};
    for (const kw of KEYWORDS) {
      errorResults[kw] = 'error';
    }
    
    return { 
      url, status: 'error',
      error_message: errorMsg,
      keyword_counts: errorResults,
      timestamp: new Date().toISOString(),
      index, total
    };
    
  } finally {
    if (page) await page.close().catch(() => {});
    if (context) await context.close().catch(() => {});
  }
}

app.post('/api/check-multiple', async (req, res) => {
  const { urls } = req.body;
  
  if (!urls || !Array.isArray(urls)) {
    return res.status(400).json({ error: 'URLs array is required' });
  }
  
  sendLog('🚀 BẮT ĐẦU KIỂM TRA', 'info');
  sendLog(`📊 Tổng số URL: ${urls.length}`, 'info');
  sendLog(`⚡ Chạy song song 10 tabs`, 'info');
  sendLog(`⚠️ Mỗi URL chỉ thử 1 lần - lỗi sẽ bỏ qua`, 'info');
  sendLog('', 'info');
  
  const PARALLEL_LIMIT = 10;
  const allResults = [];
  let batchNumber = 1;
  
  const browser = await chromium.launch({ 
    headless: true,
    args: BROWSER_ARGS
  });
  
  try {
    for (let i = 0; i < urls.length; i += PARALLEL_LIMIT) {
      const chunk = urls.slice(i, i + PARALLEL_LIMIT);
      
      sendLog(`📦 Batch ${batchNumber}: ${chunk.length} URLs`, 'info');
      
      const promises = chunk.map((url, idx) => 
        countKeywords(browser, url, i + idx + 1, urls.length)
      );
      
      const chunkResults = await Promise.all(promises);
      allResults.push(...chunkResults);
      
      await sendBatchToWebhook(chunkResults, batchNumber);
      sendLog('', 'info');
      batchNumber++;
      
      if (i + PARALLEL_LIMIT < urls.length) {
        await new Promise(r => setTimeout(r, 1000));
      }
    }
  } finally {
    await browser.close();
  }
  
  const successCount = allResults.filter(r => r.status === 'success').length;
  const skipCount = allResults.filter(r => r.status === 'skipped').length;
  const errorCount = allResults.filter(r => r.status === 'error').length;
  
  sendLog('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 'info');
  sendLog(`📊 KẾT QUẢ: ✅${successCount} ⏭️${skipCount} ❌${errorCount} / ${urls.length}`, 'info');
  sendLog('✅ HOÀN THÀNH', 'success');
  
  res.json(allResults);
});

server.listen(PORT, () => {
  console.log(`🚀 Server đang chạy tại http://localhost:${PORT}`);
});